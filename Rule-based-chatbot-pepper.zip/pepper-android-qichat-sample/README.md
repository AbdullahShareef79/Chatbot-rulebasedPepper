# pepper-android-qichat-sample

For setup see <https://qisdk.softbankrobotics.com/sdk/doc/pepper-sdk/ch1_gettingstarted/installation.html.

Follows through the Listen and reply tutorial (<https://qisdk.softbankrobotics.com/sdk/doc/pepper-sdk/ch4_api/conversation/tuto/qichatbot_tutorial.html>).
